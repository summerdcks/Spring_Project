package kr.ac.kopo.ctc.kopo36.board.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.ctc.kopo36.board.domain.Sample;

@Repository
public interface SampleRepository extends JpaRepository<Sample, Long>, JpaSpecificationExecutor<Sample>{
//	Optional<Sample> fineOneByName(String name);
//	
//	Page<Sample> findAllByType(String type, Pageable pageable);
//	
//	List<Sample> findAllType(String type);
}
