package kr.ac.kopo.ctc.kopo36.board.service;

public interface SampleService {
	String testNoAop();
	String testAop();
	
	String testNoTransactional();
	String testTransactional();
}
