package kr.ac.kopo.ctc.kopo36.board.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import kr.ac.kopo.ctc.kopo36.board.dao.SampleRepository;
import kr.ac.kopo.ctc.kopo36.board.domain.Sample;

@Service
public class SampleServiceImpl implements SampleService{
	
	@Autowired
	private SampleRepository sampleRepository;

	@Override
	public String testNoAop() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String testAop() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String testNoTransactional() {
		Sample sample = sampleRepository.findById(1L).get();
		sample.setTitle("update1");
		sampleRepository.save(sample);

		throw new RuntimeException("Spring Boot No Transactional Test");
	}
	@Override
	@Transactional
	public String testTransactional() {
		Sample sample = sampleRepository.findById(1L).get();
		sample.setTitle("update1");
		sampleRepository.save(sample);

		throw new RuntimeException("Spring Boot Transactional Test");		
	}
}
