package kr.ac.kopo.ctc.kopo36.board.service;

public interface BoardItemService {
	int add(int a, int b);
	
	void test();
	void testAopBefore();
	void testAopAfter();
	String testAopAfterReturning();
	void testAopAfterThrowing();
	void testAopAround();

}
