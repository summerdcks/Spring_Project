package kr.ac.kopo.ctc.kopo36.board.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.ac.kopo.ctc.kopo36.board.dao.SampleCondition;
import kr.ac.kopo.ctc.kopo36.board.dao.SampleMapper;
import kr.ac.kopo.ctc.kopo36.board.dao.SampleRepository;
import kr.ac.kopo.ctc.kopo36.board.dao.SampleSpecs;
import kr.ac.kopo.ctc.kopo36.board.domain.Sample;

@Controller
public class SampleController {

	@Autowired
	private SampleRepository sampleRepository;
	
	@Autowired
	private SampleMapper sampleMapper;
	
	@RequestMapping(value="/sample/list")
	@ResponseBody
	public List<Sample> list(Model model) {
		return sampleRepository.findAll();
	}
		
	@RequestMapping(value= "/sample1")
	@ResponseBody
	public List<Sample> hello1(Model model) {
		
		Map<String, Object> filter = new HashMap<String, Object>();
		filter.put("title", "2");
		
		PageRequest pageable = PageRequest.of(0, 10);
		Page<Sample> page = sampleRepository.findAll(SampleSpecs.search(filter), pageable);
		
		Long[] ids = new Long[10];
		int cnt = 0;
		for(Sample u : page) {
			ids[cnt] = u.getId();
			System.out.println(u.getTitle());
			model.addAttribute("title", u.getTitle());
			model.addAttribute("id", u.getId());
			cnt++;
		}		
		return page.getContent();
	}		
	
	@RequestMapping(value= "/sample/findAll")
	@ResponseBody
	public List<Sample> findAll(Model model) {
		List<Sample> samples = sampleMapper.findAll();
		for(Sample sample : samples) {
			System.out.println(sample.getTitle());
			model.addAttribute("title", sample.getTitle());
		}
		return samples;
	}
	
	@RequestMapping(value= "/sample3")
	@ResponseBody
	public List<Sample> findAllByCondition() {
		SampleCondition sampleCondition = new SampleCondition();
		sampleCondition.setTitle("a");
		
		RowBounds rowBounds = new RowBounds(0,10);
		
		List<Sample> samples = sampleMapper.findAllByCondition(sampleCondition, rowBounds);
		
		return samples;
	}
}
