package kr.ac.kopo.ctc.kopo36.board.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.ctc.kopo36.board.domain.Member;
import kr.ac.kopo.ctc.kopo36.board.domain.Phone;

@Repository
public interface PhoneRepository extends JpaRepository<Phone, Integer>{
	
}
