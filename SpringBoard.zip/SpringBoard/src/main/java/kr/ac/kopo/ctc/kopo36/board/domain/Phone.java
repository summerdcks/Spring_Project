package kr.ac.kopo.ctc.kopo36.board.domain;

import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Phone {
	@Id
	@GeneratedValue
	@Column
	private Integer id;
	
	@Column
	private String no;
	
	public Phone() {
		
	}
	
	public Phone (String no) {
		this.no = no;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	@ManyToOne(optional=false)
	@JoinColumn(name="member_id")
	private Member member;
	
	@Override
	public String toString() {
		String result = "[phone_"+id+"]" + no;
		return result;
	}
}
