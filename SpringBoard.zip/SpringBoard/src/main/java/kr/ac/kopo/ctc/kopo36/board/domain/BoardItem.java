package kr.ac.kopo.ctc.kopo36.board.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BoardItem {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id; //게시글 번호
	
	@Column
	private String author; //게시글 작성자
	
	@Column
	private String subject; //게시글 제목
	
	@Column
	private String content; //게시글 본문
}
