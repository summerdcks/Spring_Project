package kr.ac.kopo.ctc.kopo36.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
