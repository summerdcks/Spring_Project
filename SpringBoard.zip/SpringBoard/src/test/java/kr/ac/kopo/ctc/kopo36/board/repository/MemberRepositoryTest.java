package kr.ac.kopo.ctc.kopo36.board.repository;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import kr.ac.kopo.ctc.kopo36.board.dao.MemberRepository;
import kr.ac.kopo.ctc.kopo36.board.domain.Member;
import kr.ac.kopo.ctc.kopo36.board.domain.Phone;

@RunWith(SpringRunner.class)
@SpringBootTest
public class MemberRepositoryTest {
	
	@Autowired
	private MemberRepository memberRepository;

	@Test
	public void insertAll() {
		Member first = new Member("Jung");
		first.addPhone(new Phone("010-1234-5678"));		
		
		Member second = new Member("Dong");
		second.addPhone(new Phone("010-1111-1111"));
		
		Member third = new Member("Min");
		third.addPhone(new Phone("000-2222-2222"));
		
		memberRepository.save(first);
		memberRepository.save(second);
		memberRepository.save(third);
	}
	

	@Test
	public void selectAll() {		
		List<Member> list = memberRepository.findAll();
		for( Member m : list ) {
			System.out.println("Name :" + m.getName());
			System.out.println("Age :" + m.getAge());
			System.out.println("Id :" + m.getId());
			System.out.println("Phone :" + m.getPhones());
		}
	}
	
	@Disabled
	@Test
	public void selectOne() {		
		List<Member> member = memberRepository.findByNameAndAgeLessThan("Jung", 1);
		Member m = member.get(0);
		System.out.println("Name :" + m.getName());
		System.out.println("Age :" + m.getAge());
		System.out.println("Id :" + m.getId());
		System.out.println("Phone :" + m.getPhones());
	}	
	

	@Test
	public void updateById() {		
		Member update = new Member("James");
		update.setId(653);
		update.setAge(30);
		memberRepository.save(update);
	}
	

	@Test
	public void deleteAll() {		
		memberRepository.deleteAll();
	}
}
