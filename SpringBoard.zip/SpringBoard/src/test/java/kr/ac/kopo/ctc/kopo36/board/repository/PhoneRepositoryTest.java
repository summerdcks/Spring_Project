package kr.ac.kopo.ctc.kopo36.board.repository;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import kr.ac.kopo.ctc.kopo36.board.dao.PhoneRepository;
import kr.ac.kopo.ctc.kopo36.board.domain.Member;
import kr.ac.kopo.ctc.kopo36.board.domain.Phone;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PhoneRepositoryTest {
	@Autowired
	private PhoneRepository phoneRepository;
	

	@Test
	public void insertAll() {
		Phone phone = new Phone("010-1234-5678");
		Member mb = new Member();
		mb.setId(1053);
		phone.setMember(mb);	

		phoneRepository.save(phone);
		
	}

	@Test
	public void selectAll() {		
		List<Phone> list = phoneRepository.findAll();
		for( Phone m : list ) {
			System.out.println("No : " + m.getNo());
			System.out.println("Id : " + m.getId());
			System.out.println("Member :" + m.getMember());
		}
	}
	

	@Test
	public void updateById() {		
		Phone update = new Phone("010-9999-9999");
		Member mb = new Member();
		mb.setId(1053);
		update.setId(1053);
		update.setMember(mb);
		phoneRepository.save(update);
	}
	

	@Test
	public void delete() {		
		phoneRepository.deleteAll();
	}
}
