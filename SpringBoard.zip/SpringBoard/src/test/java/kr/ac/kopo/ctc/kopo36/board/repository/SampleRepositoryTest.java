package kr.ac.kopo.ctc.kopo36.board.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import kr.ac.kopo.ctc.kopo36.board.dao.SampleRepository;
import kr.ac.kopo.ctc.kopo36.board.web.HelloController;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SampleRepositoryTest {
	
	@Autowired
	private SampleRepository sampleRepository;


	
	@BeforeEach
	public void before() {
		System.out.println("before");
	}
	
	@AfterEach
	public void after() {
		System.out.println("after");
	}
	
	@Test
	public void findAll() {
		assertEquals(12, sampleRepository.count());
	}
	
	@Test
	public void equalTest() {
		assertEquals("a", "a");
	}
	
	@Test
	@Disabled
	public void notEqualTest() {
		assertEquals("a", "b");
	}
	
	

}
