package kr.ac.kopo.ctc.kopo36.board.service;

public interface BoardItemService {

}
