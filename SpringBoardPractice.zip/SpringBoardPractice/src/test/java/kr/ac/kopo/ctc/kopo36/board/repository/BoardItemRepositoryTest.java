package kr.ac.kopo.ctc.kopo36.board.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import kr.ac.kopo.ctc.kopo36.board.dao.BoardItemRepository;
import kr.ac.kopo.ctc.kopo36.board.domain.BoardItem;

@SpringBootTest
public class BoardItemRepositoryTest {

	@Autowired
	BoardItemRepository boardItemRepository;
	
	@Test
	void findAll() {		
		List<BoardItem> boards = boardItemRepository.findAll();
		for( BoardItem m : boards ) {
			System.out.println("bunho :" + m.getBunho());
			System.out.println("ilja :" + m.getIlja());
			System.out.println("jemok :" + m.getJemok());
			System.out.println("naeyong :" + m.getNaeyong());
		}
	}
}
